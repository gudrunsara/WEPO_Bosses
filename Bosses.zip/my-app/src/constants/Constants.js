
export const GETBOSSES = 'GETBOSSES';

export const ADDBOSS = 'ADDBOSS';

export const GETBOSS = 'GETBOSS';