import { combineReducers} from 'redux'; 
import bosses from './BossReducer';

export default combineReducers({
  /* This is the Redux store state structure */
  bosses

})