
# The project 
The project was built with create-react-app. 

# To run the project: 
npm i react-router-dom 